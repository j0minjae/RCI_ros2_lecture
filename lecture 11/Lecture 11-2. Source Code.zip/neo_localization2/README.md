# neo_localization2

Please visit [our documentation](https://neobotix-docs.de/ros/packages/neo_localization.html) to know more about the setup and the usage of this package.

