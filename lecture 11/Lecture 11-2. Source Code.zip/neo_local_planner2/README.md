# neo_local_planner2
Pure-pursuit based local planner for ROS-2

Please find our documentations in https://neobotix-docs.de/ros/packages/neo_local_planner.html