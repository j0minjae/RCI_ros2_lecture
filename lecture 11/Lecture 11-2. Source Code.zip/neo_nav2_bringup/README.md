# neo_nav2_bringup
Common nav2 bringup package for all the robots

Boiler plate launch files for the Nav2

You can find the documentation for this package here: https://neobotix-docs.de/ros/packages/neo_nav2_bringup.html
