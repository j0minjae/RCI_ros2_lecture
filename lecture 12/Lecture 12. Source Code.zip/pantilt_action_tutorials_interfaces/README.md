#pantilt_actions_tutorial_interfaces package

Package to illustrate the ROS 2 definition of a custom interface to define actions.

Used in the [Communications using actions tutorial](https://sir.upc.edu/projects/ros2tutorials/6-communications_using_actions/index.html) of the Introduction to ROS course.


## Usage

This package is used in package *actions_tutorial* where a action_client-action_server communicate using the action described here.
